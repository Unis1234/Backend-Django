from django.apps import AppConfig


class HomepageappConfig(AppConfig):
    name = 'homepageapp'
